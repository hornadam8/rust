use std::ops::Deref;

fn main() {
    let mut nav_items = vec![];
    nav_items.push(NavItem {id: 1, content: "item 1 root".to_string(), parent_id: None});
    nav_items.push(NavItem {id: 2, content: "item 2 root".to_string(), parent_id: None});
    nav_items.push(NavItem {id: 3, content: "item 3 root".to_string(), parent_id: None});
    nav_items.push(NavItem {id: 4, content: "item 4 sub 2".to_string(), parent_id: Some(2)});
    nav_items.push(NavItem {id: 5, content: "item 5 sub 2".to_string(), parent_id: Some(2)});
    nav_items.push(NavItem {id: 6, content: "item 6 sub 4".to_string(), parent_id: Some(4)});
    nav_items.push(NavItem {id: 7, content: "item 7 sub 1".to_string(), parent_id: Some(1)});
    nav_items.push(NavItem {id: 8, content: "item 8 sub 3".to_string(), parent_id: Some(3)});
    nav_items.push(NavItem {id: 9, content: "item 9 sub 6".to_string(), parent_id: Some(6)});
    nav_items.push(NavItem {id: 10, content: "item 10 sub 5".to_string(), parent_id: Some(5)});
    nav_items.push(NavItem {id: 11, content: "item 11 sub 6".to_string(), parent_id: Some(6)});
    print_tree(nav_items);
}

#[derive(Clone)]
struct NavItem {
  id: i32,
  content: String,
  parent_id: Option<i32>,
}

fn print_tree(items: Vec<NavItem>) {
    let mut roots = vec![];
    let mut children = vec![];
    for item in items.into_iter() {
        if item.parent_id.is_some() {
            children.push(item);
        } else {
            roots.push(item);
        }
    }
    for root in roots.iter() {
        print_with_children(root, &children, 0);
    }
}

fn print_with_children(item: &NavItem, items: &Vec<NavItem>, level: i32) {
    let mut space = "".to_string();
    for _ in 0..level {
        space += "    ";
    }
    println!("{}{}", space, item.content);
    for it in items.iter() {
        if it.parent_id.unwrap_or(-1) == item.id {
            print_with_children(it, items, level+1);
        }
    }
}